/*
Instructions:
1. The first person becomes affected by dengue when a mosquito bites them.
2. Use the arrow keys to control the mosquito's movement.
3. Initially, press the arrow keys to move the mosquito closer to the first person. Once the mosquito bites, the person's head will change color to indicate they are infected.
4. Press the 'T' key to eliminate the mosquito and save the first person from dengue.
*/

#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <GL/glut.h>
#include <iostream>
using namespace std;
int status = 0;

float sr=0.0f,sg=0.5f,sb=1.0f;//original colors of the sky -baby blue
float snr= 1.0f,sng= 1.0f,snb= 0.0f;//colors of the sun
float cdr=1.0f,cdg=1.0f,cdb=1.0f;//colors of the clouds
float m2r=0,m2g=0.5f,m2b=1.0f;
float gdr=0,gdg=0.4,gdb=0;//grass color



float mosquitoY[20] = { 310.0f, 315.0f, 325.0f, 310.0f, 315.0f, 325.0f, 280.0f, 270.0f,
                        300.0f, 310.0f, 305.0f, 320.0f, 330.0f, 325.0f, 315.0f, 285.0f,
                        290.0f, 300.0f, 310.0f, 320.0f
                      };

float mosquitoX[20] = {50.0f, 100.0f, 70.0f, 90.0f, 40.0f, 110.0f, 75.0f, 60.0f, 120.0f, 85.0f,
                       105.0f, 30.0f, 95.0f, 60.0f, 125.0f, 45.0f, 50.0f, 65.0f, 110.0f, 35.0f
                      };


// Variables for fireball position, velocity, and gravity
float fireballX = 620.0f, fireballY = 250.0f;  // Initial position relative to the hand
float velocityX = -5.0f, velocityY = 5.0f;  // Initial velocities for horizontal and vertical motion
float gravity = -0.1f;  // Gravity effect (downward aceleration)
bool throwFireball = false;  // Flag to control fireball throwing animation
float targetX = -10.0f, targetY = -257.0f;  // Target (dust shape location)

// Global variables for managing the overlay and timer
bool showWhiteOverlay = false;  // Flag for white overlay
float overlayStartTime = 0.0f;  // Time when overlay started
bool tPressed = false;

bool removeMosquitoes = false;
float mosquitoRemovalTime = 0.0f;



void init(void)
{
    glClearColor(1.0, 1.0, 1.0, 0.0);
    glColor3f(0.0f, 0.0f, 0.0f);
    glPointSize(4.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0.0, 902.0, 0.0, 684.0);
}
void drawCircle(GLfloat x, GLfloat y, GLfloat radius)
{
    int nbTrng = 50;
    GLfloat twicePi = 2.0f *3.14159265359;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2d(x, y);
    for(int i = 0; i <= nbTrng; i++)
    {
        glVertex2d(
            x + (radius * cos(i *  twicePi / nbTrng)),
            y + (radius * sin(i * twicePi / nbTrng))
        );
    }
    glEnd();
}
void sky()
{
    glPushMatrix();
    glColor3f(sr,sg,sb);
    glBegin(GL_QUADS);
    glVertex2i(0,684);glVertex2i(902,684);glVertex2i(902,0);glVertex2i(0,0);
    glEnd();
    glPopMatrix();
    glutPostRedisplay();
}
void sun()
{
    glColor3f(snr,sng,snb);
    drawCircle(824.0f,615.0f,40.0f);
    glutPostRedisplay();
}
void windows(int x,int y)
{
    glPushMatrix();
    glColor3f(0,0,0);
    glBegin(GL_QUADS);
    glVertex2i(x,y);glVertex2i(x+12,y);glVertex2i(x+12,y+18);glVertex2i(x,y+18);
    glEnd();
    glPopMatrix();
}


void drawWhiteOverlay()
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor4f(1.0f, 1.0f, 1.0f, 0.4f);  // White with 0.4 opacity

    glBegin(GL_QUADS);
    glVertex2i(0, 0);glVertex2i(902, 0);glVertex2i(902, 684);glVertex2i(0, 684);
    glEnd();
    glDisable(GL_BLEND);
}

void drawHuman(float x, float y)
{
    bool mosquitoOnHead = false;
    for (int i = 0; i < 10; i++)
    {
        float dx = mosquitoX[i] - x;
        float dy = mosquitoY[i] - y;
        float distance = sqrt(dx * dx + dy * dy);

        if (distance <= 15.0f)
        {
            mosquitoOnHead = true;
            break;
        }
    }


    glLineWidth(3.0f);
    if (mosquitoOnHead)
    {
        glColor3ub(0, 0, 255);
    }
    else
    {
        glColor3ub(255, 204, 153);
    }
    drawCircle(x, y, 15.0f);
    glColor3f(0.0f, 0.5f, 1.0f);

    // Body (a vertical line)
    glBegin(GL_LINES);
    glVertex2f(x, y - 15.0f); glVertex2f(x, y - 75.0f);
    glEnd();

    // Left Arm (a line)
    glBegin(GL_LINES);
    glVertex2f(x, y - 25.0f); glVertex2f(x - 25.0f, y - 50.0f);
    glEnd();

    // Right Arm (a line)
    glBegin(GL_LINES);
    glVertex2f(x, y - 25.0f); glVertex2f(x + 25.0f, y - 50.0f);
    glEnd();

    // Left Leg (a line)
    glBegin(GL_LINES);
    glVertex2f(x, y - 75.0f); glVertex2f(x - 15.0f, y - 110.0f);
    glEnd();

    // Right Leg (a line)
    glBegin(GL_LINES);
    glVertex2f(x, y - 75.0f); glVertex2f(x + 15.0f, y - 110.0f);
    glEnd();

    glLineWidth(1.0f);
}


void drawManWithFire(float x, float y)
{
    glLineWidth(5.0f);

    glColor3ub(255, 204, 153);
    drawCircle(x, y, 15.0f);

    glColor3f(0.0f, 0.5f, 1.0f);

    // Body (a vertical line)
    glBegin(GL_LINES);
    glVertex2f(x, y - 15.0f); glVertex2f(x, y - 75.0f);
    glEnd();

    // Left Arm (a line)
    glBegin(GL_LINES);
    glVertex2f(x, y - 25.0f); glVertex2f(x - 25.0f, y - 50.0f);
    glEnd();

    glBegin(GL_LINES);
    glVertex2f(x, y - 25.0f); glVertex2f(x + 25.0f, y - 50.0f);
    glEnd();

    // Left Leg (a line)
    glBegin(GL_LINES);
    glVertex2f(x, y - 75.0f); glVertex2f(x - 15.0f, y - 110.0f);
    glEnd();

    // Right Leg (a line)
    glBegin(GL_LINES);
    glVertex2f(x, y - 75.0f); glVertex2f(x + 15.0f, y - 110.0f);
    glEnd();
}


void updateFireballPosition()
{
    if (throwFireball)
    {

        fireballX += velocityX;
        fireballY += velocityY;

        velocityY += gravity;

        if (fabs(fireballX - targetX) < 10.0f && fabs(fireballY - targetY) < 10.0f)
        {

            throwFireball = false;
        }
    }
}


void hospital()
{
    glPushMatrix();
    glColor3ub(252,222,66);
    glBegin(GL_QUADS);
    glVertex2i(151,257); glVertex2i(181,257);
    glVertex2i(181,424); glVertex2i(151,424);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(252,222,66);
    glBegin(GL_QUADS);
    glVertex2i(449,257); glVertex2i(449,424);
    glVertex2i(420,424); glVertex2i(420,257);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(252,222,66);
    glBegin(GL_QUADS);
    glVertex2i(181,381); glVertex2i(420,381);
    glVertex2i(420,400); glVertex2i(181,400);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(190,27,9);
    glBegin(GL_QUADS);
    glVertex2i(181,258); glVertex2i(420,258);
    glVertex2i(420,381); glVertex2i(181,381);
    glEnd();
    glPopMatrix();

    int counter1=163;
    for(int i=11; i>=0; i--)
    {
        counter1+=20;
        windows(counter1,349);
    }
    int counter2=163;
    for(int i=11; i>=0; i--)
    {
        counter2+=20;
        windows(counter2,315);
    }
    int counter3=163;
    for(int i=11; i>=0; i--)
    {
        counter3+=20;
        windows(counter3,281);
    }
    glPushMatrix(); //middle
    glColor3ub(252,222,66);
    glBegin(GL_QUADS);
    glVertex2i(263,257); glVertex2i(339,257);
    glVertex2i(339,400); glVertex2i(263,400);
    glEnd();
    glPopMatrix();

    int counter4=260;
    for(int i=3; i>=0; i--)
    {
        counter4+=14;
        windows(counter4,370);
    }
    int counter5=260;
    for(int i=3; i>=0; i--)
    {
        counter5+=14;
        windows(counter5,340);
    }
    int counter6=260;
    for(int i=3; i>=0; i--)
    {
        counter6+=14;
        windows(counter6,310);
    }

    glPushMatrix();  //Door
    glColor3f(0,0,0);
    glBegin(GL_QUADS);
    glVertex2i(286,257); glVertex2i(318,257);
    glVertex2i(318,298); glVertex2i(286,298);
    glEnd();
    glPopMatrix();

    glutPostRedisplay();
}

void hospitalLogo()
{

    glColor3ub(252,222,66);

    drawCircle(300.0f,400.0f,40.0f);


    glPushMatrix();
    glColor3ub(255,0,0);
    glBegin(GL_QUADS);
    glVertex2i(295,395); glVertex2i(307,395);
    glVertex2i(307,426); glVertex2i(295,426);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,0,0);
    glBegin(GL_QUADS);
    glVertex2i(284,408); glVertex2i(318,408);
    glVertex2i(318,418);glVertex2i(284,418);
    glEnd();
    glPopMatrix();
}

void drawMosquito(float x, float y)
{
    // Body of the mosquito (small circle)
    glColor3ub(0, 0, 0);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2d(x, y);  // Center
    for (int i = 0; i < 20; i++)
    {
        glVertex2d(x + 3 * cos(i * 2 * 3.14159 / 20), y + 3 * sin(i * 2 * 3.14159 / 20));
    }
    glEnd();

    // Wings (two small triangles)
    glBegin(GL_TRIANGLES);
    glVertex2f(x - 2.0f, y + 4.0f);  // Left wing
    glVertex2f(x, y + 1.0f);
    glVertex2f(x - 4.0f, y + 1.0f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glVertex2f(x + 2.0f, y + 4.0f);  // Right wing
    glVertex2f(x, y + 1.0f);
    glVertex2f(x + 4.0f, y + 1.0f);
    glEnd();
}


void removeAllMosquitoes()
{

    if (removeMosquitoes)
    {
        for (int i = 0; i < 20; i++)
        {
            mosquitoX[i] = -1000.0f; // Move mosquitoes off-screen or out of view
            mosquitoY[i] = -1000.0f;
        }
    }
}

void dust()
{
    // Original dust shape
    glPushMatrix();
    glColor3ub(102, 51, 0);
    glBegin(GL_QUADS);
    glVertex2i(10, 257); glVertex2i(145, 257);
    glVertex2i(145, 289); glVertex2i(10, 289);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(102, 51, 0);
    glBegin(GL_QUADS);
    glVertex2i(27, 289); glVertex2i(127, 289);
    glVertex2i(127, 320); glVertex2i(27, 320);
    glEnd();
    glPopMatrix();

    glColor3ub(102, 51, 0);
    drawCircle(77.0f, 335.0f, 22.0f);
    drawCircle(45.0f, 330.0f, 22.0f);
    drawCircle(108.0f, 330.0f, 22.0f);

    // Draw mosquitoes using both X and Y positions
    for (int i = 0; i < 20; i++)
    {
        drawMosquito(mosquitoX[i], mosquitoY[i]);
    }
}
void building()
{
    glPushMatrix();
    glColor3ub(8,32,19);
    glBegin(GL_QUADS);
    glVertex2i(449,257); glVertex2i(644,257);
    glVertex2i(644,289); glVertex2i(449,289);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(23,60,43);
    glBegin(GL_QUADS);
    glVertex2i(473,289); glVertex2i(500,289);
    glVertex2i(500,413); glVertex2i(473,413);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(15,47,106);
    glBegin(GL_QUADS);
    glVertex2i(500,289); glVertex2i(517,289);
    glVertex2i(517,435); glVertex2i(500,435);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(21,63,53);
    glBegin(GL_QUADS);
    glVertex2i(517,289); glVertex2i(617,289);
    glVertex2i(617,408); glVertex2i(517,408);
    glEnd();
    glPopMatrix();

    glColor3ub(23,60,43);  // side circle
    drawCircle(475.0f,310.0f,18.0f);
    drawCircle(475.0f,348.0f,18.0f);
    drawCircle(475.0f,383.0f,18.0f);

    int bcounter1=430;
    for(int i=7; i>=0; i--)
    {
        bcounter1+=24;
        windows(bcounter1,267);
    }
    int bcounter2=498;
    for(int i=3; i>=0; i--)
    {
        bcounter2+=24;
        windows(bcounter2,377);
    }
    int bcounter3=498;
    for(int i=3; i>=0; i--)
    {
        bcounter3+=24;
        windows(bcounter3,350);
    }
    int bcounter4=498;
    for(int i=3; i>=0; i--)
    {
        bcounter4+=24;
        windows(bcounter4,323);
    }
    int bcounter5=498;
    for(int i=3; i>=0; i--)
    {
        bcounter5+=24;
        windows(bcounter5,295);
    }
}
void school()
{
    glPushMatrix();
    glColor3ub(214,130,5);
    glBegin(GL_QUADS);
    glVertex2i(643,257); glVertex2i(884,257);
    glVertex2i(884,351); glVertex2i(643,351);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(73,3,5);
    glBegin(GL_QUADS);
    glVertex2i(640,351); glVertex2i(887,351);
    glVertex2i(887,358); glVertex2i(640,358);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(80,149,146);
    glBegin(GL_QUADS);
    glVertex2i(648,265); glVertex2i(719,265);
    glVertex2i(719,275); glVertex2i(648,275);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(80,149,146);
    glBegin(GL_QUADS);
    glVertex2i(808,265); glVertex2i(879,265);
    glVertex2i(879,275); glVertex2i(808,275);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(217,132,3);
    glBegin(GL_POLYGON);
    glVertex2i(713,358); glVertex2i(813,358);
    glVertex2i(813,381); glVertex2i(763,402);
    glVertex2i(713,381);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(75,3,4);
    glBegin(GL_TRIANGLES);
    glVertex2i(707,381);glVertex2i(819,381);
    glVertex2i(763,409);
    glEnd();
    glPopMatrix();

    glColor3ub(200,200,240);
    drawCircle(762.0f,369.0f,10.0f);
    int scounter1=623;
    for(int i=2; i>=0; i--)
    {
        scounter1+=25;
        windows(scounter1,328);
    }
    int scounter2=623;
    for(int i=2; i>=0; i--)
    {
        scounter2+=25;
        windows(scounter2,304);
    }
    int scounter3=623;
    for(int i=2; i>=0; i--)
    {
        scounter3+=25;
        windows(scounter3,281);
    }
    int scounter4=783;
    for(int i=2; i>=0; i--)
    {
        scounter4+=25;
        windows(scounter4,328);
    }
    int scounter5=783;
    for(int i=2; i>=0; i--)
    {
        scounter5+=25;
        windows(scounter5,304);
    }
    int scounter6=783;
    for(int i=2; i>=0; i--)
    {
        scounter6+=25;
        windows(scounter6,282);
    }
    glPushMatrix();//door
    glColor3ub(72,2,4);
    glBegin(GL_QUADS);
    glVertex2i(728,257);glVertex2i(797,257);
    glVertex2i(797,321);glVertex2i(728,321);
    glEnd();
    glPopMatrix();

    glPushMatrix();//triangle of the door
    glColor3ub(75,3,4);
    glBegin(GL_TRIANGLES);
    glVertex2i(722,321);glVertex2i(803,321);
    glVertex2i(763,347);
    glEnd();
    glPopMatrix();
}
void cloud()
{
    glPushMatrix();
    glColor3f(cdr,cdg,cdb);
    drawCircle(594.0f,586.0f,20.0f);drawCircle(572.0f,595.0f,28.0f);
    drawCircle(539.0f,595.0f,35.0f);drawCircle(513.0f,575.0f,20.0f);
    glPopMatrix();

    glPushMatrix();
    drawCircle(393.0f,577.0f,20.0f);drawCircle(370.0f,585.0f,28.0f);
    drawCircle(339.0f,583.0f,35.0f);drawCircle(311.0f,565.0f,20.0f);
    glPopMatrix();

    glPushMatrix();
    drawCircle(193.0f,607.0f,20.0f);drawCircle(170.0f,615.0f,28.0f);
    drawCircle(139.0f,613.0f,35.0f);drawCircle(111.0f,595.0f,20.0f);
    glPopMatrix();
}
void street()
{
    glPushMatrix();
    glColor3ub(0,0,0);
    glBegin(GL_QUADS);
    glVertex2i(0,148);glVertex2i(902,148);
    glVertex2i(902,47);glVertex2i(0,47);
    glEnd();
    glPopMatrix();

    for(int i=0; i<120*8; i+=120)
    {
        glPushMatrix();
        glColor3ub(255,255,255);
        glBegin(GL_QUADS);
        glVertex2i(0+i,95);
        glVertex2i(35+i,95);
        glVertex2i(35+i,100);
        glVertex2i(0+i,100);
        glEnd();
        glPopMatrix();
    }
}
void belowStreet()
{
    glPushMatrix();
    glColor3f(gdr,gdg,gdb);
    glBegin(GL_QUADS);
    glVertex3f(0.0,0.0,0.0);glVertex3f(902.0,0.0,0.0);
    glVertex3f(902.0,47.0,0.0);glVertex3f(0.0,47.0,0.0);
    glEnd();
    glPopMatrix();
}
void aboveStreet()
{
    glPushMatrix();
    glColor3f(gdr,gdg,gdb);
    glBegin(GL_QUADS);
    glVertex3f(0.0,157.0,0.0);glVertex3f(902.0,157.0,0.0);
    glVertex3f(902.0,258.0,0.0);glVertex3f(0.0,258.0,0.0);
    glEnd();
    glPopMatrix();
}
void lamp()
{
    for(int i=0; i<8*115; i+=115)
    {
        glPushMatrix();
        glColor3f(0,0,0);
        glBegin(GL_QUADS);
        glVertex2i(34+i,158);glVertex2i(51+i,158);
        glVertex2i(51+i,160);glVertex2i(34+i,160);
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glColor3f(0,0,0);
        glBegin(GL_QUADS);
        glVertex2i(37+i,160);glVertex2i(48+i,160);
        glVertex2i(48+i,162);glVertex2i(37+i,162);
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glColor3f(0,0,0);
        glBegin(GL_QUADS);
        glVertex2i(40+i,162);glVertex2i(45+i,162);
        glVertex2i(45+i,206);glVertex2i(40+i,206);
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glColor3ub(0,0,0);
        glBegin(GL_QUADS);
        glVertex2i(38+i,206);glVertex2i(48+i,206);
        glVertex2i(48+i,209);glVertex2i(38+i,209);
        glEnd();
        glPopMatrix();
    }
}
void draw(void)
{
    glClear(GL_COLOR_BUFFER_BIT);

    sky();
    hospitalLogo();
    hospital();
    building();
    school();
    sun();
    cloud();

    aboveStreet();
    street();
    belowStreet();
    drawHuman(195.0f, 300.0f);
    drawManWithFire(595.0f, 300.0f);
    updateFireballPosition();

    // Draw the fireball at its current position
    glColor3f(1.0f, 0.0f, 0.0f);  // Orange color for the fireball
    drawCircle(fireballX, fireballY, 10.0f);

    dust();
    if (showWhiteOverlay)
    {
        drawWhiteOverlay();
        float elapsedTime = (float)glutGet(GLUT_ELAPSED_TIME) - overlayStartTime;

        if (elapsedTime >= 800)
        {
            showWhiteOverlay = false;
        }
        if (elapsedTime >= 500.0f )
        {
            removeMosquitoes = true;
            removeAllMosquitoes();
        }
    }
    glutSwapBuffers();
}

void keyboard( unsigned char key, int x, int y )
{
    if (key == 't' || key == 'T')
    {

        if (!tPressed)
        {
            throwFireball = true;
            showWhiteOverlay = true;
            overlayStartTime = (float)glutGet(GLUT_ELAPSED_TIME);
            mosquitoRemovalTime = overlayStartTime + 500.0f;
            tPressed = true;

        }
    }
}

void specialKey(int key, int x, int y)
{
    switch (key)
    {
    case GLUT_KEY_UP:
        for (int i = 0; i < 10; i++)
        {
            mosquitoY[i] += 10.0f;
        }
        break;

    case GLUT_KEY_DOWN:
        for (int i = 0; i < 10; i++)
        {
            mosquitoY[i] -= 10.0f;
        }
        break;

    case GLUT_KEY_LEFT:
        for (int i = 0; i < 10; i++)
        {
            mosquitoX[i] -= 10.0f;
        }
        break;

    case GLUT_KEY_RIGHT:
        for (int i = 0; i < 10; i++)
        {
            mosquitoX[i] += 10.0f;
        }
        break;
    }
    glutPostRedisplay();

}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE| GLUT_RGB);
    glutInitWindowSize (902,684);
    glutInitWindowPosition (250, 50);
    glutCreateWindow("Mosquito Animation");
    glutDisplayFunc(dust);
    glutCreateWindow ("Street & Buildings");
    glutDisplayFunc(draw);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKey);
    init();
    glutMainLoop();
}
